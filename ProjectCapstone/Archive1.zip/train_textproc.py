#!/usr/bin/python
# encoding: UTF-8


import numpy as np
import sys

# No. of different characters able to handle
num_char = 98

##################################################
############# Data Reader Function ###############
##################################################

def read_data(description, validation=True):
    """
    Returns: training data, validation data, list of reviews with ranges
    No validation data is returned if there are 5 documents or less.
    :param validation: if True (default), sets the last document aside as validation data
    """
    ascii_text = []
    reviewlen = []
    counter =0

    for string in description:
        start = len(ascii_text)
        ascii_text.extend(enc_text(string + ' '))
        end = len(ascii_text)
        reviewlen.append({"start": start, "end": end, "name": 'line %s' % counter})
        counter+=1

    if len(reviewlen) == 0:
        sys.exit("No training data has been found. Aborting training")

    # Take 5% of reviews for validation
    nb_reviews = len(reviewlen) // 20

    if nb_reviews == 0 or not validation:
        cutoff = len(ascii_text)
    else:
        cutoff = reviewlen[-nb_reviews]["start"]
    valitext = ascii_text[cutoff:]
    ascii_text = ascii_text[:cutoff]
    return ascii_text, valitext, reviewlen


def find_review(index, reviewlen):
    return next(
        review["name"] for review in reviewlen if (review["start"] <= index < review["end"]))


def find_review_index(index, reviewlen):
    return next(
        i for i, review in enumerate(reviewlen) if (review["start"] <= index < review["end"]))


##################################################
####### Encoding and decoding functions ##########
##################################################

def enc_text(string):
    """Encodes a string in Ascii.
    Returns: Ascii code of string
    """
    return list(map(lambda x: conv_fr_char(ord(x)), string))


def dec_to_text(c, avoid_tab=False):
    """Decode back to characters.
    avoid_tab if True, tab and line feed characters are replaced by '\'
    """
    return "".join(map(lambda x: chr(conv_to_char(x, avoid_tab)), c))


def conv_fr_char(char):
    """Returns: adjusted Ascii code of char"""

    if char == 9:
        return 1            # For Tab
    if char == 10:
        return 127- 30      # To handle line feed
    elif 32 <= char <=126:
        return char - 30
    else:
        return 0            # Handle unknowns

### Unknown = 0, Tab = 1, space = 2, Line feed = 97
### All alphabets mapped between 3 - 96 (including upper and lower case)

def conv_to_char(num, avoid_tab=False):
    """Returns adjusted back true Ascii code of num
    avoid_tab if True, tab and line feed characters are replaced by '\'
    """
    if num == 1:
        return 32 if avoid_tab else 9  # Space instead of TAB
    if num == 127 - 30:
        return 92 if avoid_tab else 10  # \ instead of LF
    if 32 <= num + 30 <= 126:
        return num + 30
    else:
        return 0  # Unknowns

def sample_from_prob(prob, top_n=num_char):
    """Samples an integer in the [0 - num_char] range, with a provided
    probability p. If top_n is specified, only the topn highest probabilities are taken into account.
        - prob: a list of size num_char with individual probabilities
        - top_n: the number of highest probabilities to consider. Defaults to all of them.
    Returns: a random integer
    """
    p = np.squeeze(prob)
    p[np.argsort(p)[:-top_n]] = 0
    p = p / np.sum(p)
    return np.random.choice(num_char, 1, p=p)[0]



##################################################
########## Batch Sequencing Function #############
##################################################

def sequencer(raw_text, batch_size, sequence_size, num_epochs):
    """
    Chops up the data and reshapes into batches of sequences in one wide array
    so that all the sequences in one batch continue in the next batch.
    This generator will keep returning batches until the input data has been
    seen num_epochs times. Sequences are continued even between epochs.
        - raw_text: training text
        - batch_size: size of a batch
        - sequence_size: sequence of characters in each row
        - num_epochs: number of epochs to train on
    :Returns:
        x: one batch of training sequence
        y: one batch of target sequence, but shifted by 1
        epoch: the current epoch number (starting at 0)
    """
    data = np.array(raw_text)
    data_len = data.shape[0]
    ## (data_len-1) because we must provide for the sequence shifted by 1 too ##
    num_batches = (data_len - 1) // (batch_size * sequence_size)
    assert (num_batches) > 0, "Not enough data, even for a single batch. Try a smaller batch_size."
    rounded_data_len = num_batches * batch_size * sequence_size #The remainder at the end of raw_data
                                                                #that does not fit in an full batch is IGNORED.
    xarray = np.reshape(data[0:rounded_data_len], [batch_size, num_batches * sequence_size])
    yarray = np.reshape(data[1:rounded_data_len + 1], [batch_size, num_batches * sequence_size])

    for epoch in range(num_epochs):
        for batch in range(num_batches):
            x = xarray[:, batch * sequence_size:(batch + 1) * sequence_size]
            y = yarray[:, batch * sequence_size:(batch + 1) * sequence_size]
            x = np.roll(x, -epoch, axis=0)  # to continue the text from epoch to epoch (do not reset rnn state!)
            y = np.roll(y, -epoch, axis=0)
            yield x, y, epoch


##################################################
############# Printing functions #################
##################################################

def print_data_stats(datalen, valilen, epoch_size):
    datalen_mb = datalen/1024.0/1024.0
    valilen_kb = valilen/1024.0

    print "Training text size is {:.2f}MB \nValidation text size is {:.2f}KB \n".format(datalen_mb, valilen_kb)\
          + "There are {} batches per epoch".format(epoch_size)

def print_validation_header(validation_start, reviewlen):
    reviewindex = find_review_index(validation_start, reviewlen)
    reviews = ''
    for i in range(reviewindex, len(reviewlen)):
        reviews += reviewlen[i]["name"]
        if i < len(reviewlen)-1:
            reviews += ", "
    print "{: <60}".format("Validating on :\n" + reviews)

def print_learning(X, Y, losses, reviewlen, batch_loss, batch_accuracy, epoch_size, index, epoch):
    """Display learning statistics"""

    batch_size = X.shape[0]
    sequence_len = X.shape[1]

    #Print the training sequence and predicted sequence
    for k in range(batch_size):
        decx = dec_to_text(X[k], avoid_tab=True)
        decy = dec_to_text(Y[k], avoid_tab=True)
        epoch_string = " (epoch {}) ".format(epoch)
        loss_string = "loss: {:.5f}".format(losses[k])
        print_string = epoch_string + " │ {} │ {} │ {}"
        print print_string.format(decx, decy, loss_string)
        index += sequence_len

    # Format training stats footer
    format_string = "{:-^" + str(len(epoch_string)) + "}"
    format_string += "{:-^" + str(len(decx) + 2) + "}"
    format_string += "{:-^" + str(len(decy) + 2) + "}"
    format_string += "{:-^" + str(len(loss_string)) + "}"
    footer = format_string.format('Epoch', 'Training Seq', 'Predicted Seq', 'Loss')
    print footer

    batch_index = index % (epoch_size * batch_size * sequence_len) // (batch_size * sequence_len)
    batch_string = "batch {}/{} in epoch {},".format(batch_index, epoch_size, epoch)
    stats = "{: <28} batch loss: {:.5f}, batch accuracy: {:.5f} \n\n\n".format(batch_string,
             batch_loss, batch_accuracy)
    print
    print "Training stats: {}".format(stats)
